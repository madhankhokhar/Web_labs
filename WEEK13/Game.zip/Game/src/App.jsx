import React, { useState } from 'react';

function ButtonCreator() {
  const [createdUsers, setCreatedUsers] = useState([]);
  const [createButtonDisabled, setCreateButtonDisabled] = useState(false);
  const [backwardClicked, setBackwardClicked] = useState(false); 
  const stepColors = ['#4CAF50', '#FF5733', '#FFC300', '#FF33FF', '#33FFFF']; 

  const handleCreateButtonClick = () => {
    if (createdUsers.length < 3) {
      const newUser = {
        name: getNewUserName(),
        currentColorIndex: 0
      };
      setCreatedUsers([...createdUsers, newUser]);
      setCreateButtonDisabled(true); 
    }
    setCreateButtonDisabled(true);
  };

  const handleNextButtonClick = (userIndex) => {
    setCreatedUsers(createdUsers.map((user, index) => {
      if (index === userIndex && user.currentColorIndex < stepColors.length - 1) {
        return { ...user, currentColorIndex: user.currentColorIndex + 1 };
      }
      return user;
    }));

    const user = createdUsers[userIndex];
    if (user.currentColorIndex === 3) {
      setCreateButtonDisabled(false); 
    }
    setBackwardClicked(false); 
  };

  const handleBackwardButtonClick = (userIndex) => {
    setCreatedUsers(createdUsers.map((user, index) => {
      if (index === userIndex && user.currentColorIndex > 0) {
        return { ...user, currentColorIndex: user.currentColorIndex - 1 };
      }
      return user;
    }));
    setCreateButtonDisabled(true); 
    setBackwardClicked(true); 
  };

  const getNewUserName = () => {
    switch (createdUsers.length) {
      case 0:
        return <span style={{ display: 'inline-block', verticalAlign: 'middle' }}>Alpha</span>;
      case 1:
        return <span style={{ display: 'inline-block', verticalAlign: 'middle' }}>Beta</span>;
      default:
        return <span style={{ display: 'inline-block', verticalAlign: 'middle' }}>Gamma</span>;
    }
  }; 

  return (
    <div style={{ textAlign: 'center' }}>
      <div>
        <button onClick={handleCreateButtonClick} disabled={createButtonDisabled} style={{marginButton: '20px'}}>Create User</button>
      </div>
      {createdUsers.map((user, userIndex) => (
        <div key={userIndex}>
          <button>{user.name}</button>
          <div className="step-buttons">
            <button onClick={() => handleBackwardButtonClick(userIndex)}>Backward</button> 
            {[1, 2, 3, 4].map((step, stepIndex) => (
              <button key={step} style={{ backgroundColor: stepIndex === user.currentColorIndex ? stepColors[user.currentColorIndex] : '#4CAF50' }} onClick={() => handleNextButtonClick(userIndex)}>
                Step {step}
              </button>
            ))}
            <button onClick={() => handleNextButtonClick(userIndex)}>Next</button>
          </div>
        </div>
      ))}
    </div>
  );
}

export default ButtonCreator;
